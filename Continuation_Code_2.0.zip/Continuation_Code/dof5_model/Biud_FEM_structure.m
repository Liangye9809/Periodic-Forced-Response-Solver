
FEM.Mee = Mee;
FEM.Mec = Mec;
FEM.Mcc = Mcc;

FEM.Kee = Kee;
FEM.Kec = Kec;
FEM.Kcc = Kcc;

FEM.Pe = Pe;
FEM.Pc = Pc;

FEM.Fe = Fe;
FEM.Fc = Fc;

clear Mee Mec Mcc Kee Kec Kcc Pe Pc Pe Pc