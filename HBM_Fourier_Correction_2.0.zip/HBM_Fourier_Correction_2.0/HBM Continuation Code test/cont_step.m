function [x, omega, tx, tomega, w, k, FlagState, stop] = cont_step(func, jacob, deromega, params)
     x0 = params.cont.x0;
omega_0 = params.cont.omega_0;
     ds = params.cont.ds;
    tx0 = params.cont.tx0;
tomega0 = params.cont.tomega0;
   epsx = params.Newton.epsx;
   epsf = params.Newton.epsf;
maxiter = params.Newton.maxiter;
      x = x0 + ds*tx0;
  omega = omega_0 + ds*tomega0;
      z = [x; omega];

Nx = params.func.HBM.Nx;
H  = params.func.HBM.H;
Na = params.func.HBM.Na;
E  = params.func.HBM.E;
stop = 0;

FlagState = zeros(Nx, 4);
%% calculate (min(w+) - max(w-)) / 2
% xc  = x((2 * H + 1) * Na + 1:end);
% pfunc = params.func;
% w = get_w_middle(xc, pfunc);
% params.func.fc.w = w;
%%
xct = Fourier_to_Time(x(Na * (2 * H + 1) + 1:end), H, Nx, E);
[F, w, JL, flag] = func(x, xct, omega, params.func);

params.func.fc.w = w; % update w
G = [F 
     tx0' * (x - x0) + tomega0 * (omega - omega_0) - ds];
for k = 1:maxiter
    JG = [jacob(x, xct, params.func, JL, flag) deromega(x, omega, params.func)
          tx0' tomega0];
    % A = [jacob(x, omega, params.func) deromega(x, omega, params.func)];
    % e_ = svd(A);
    dz = -JG\G;
    z = z + dz;
    x = z(1:end-1);
    omega = z(end);
    % FUNCstruct = func(x, omega, params.func);
    xct = Fourier_to_Time(x(Na * (2 * H + 1) + 1:end), H, Nx, E);
    [F, w, JL, flag] = func(x, xct, omega, params.func);
    % params.func.fc.w = FUNCstruct.w; % update w

    params.func.fc.w = w; % update w
    % w = get_w_middle(xc, pfunc);
    % params.func.fc.w = w;

    G = [F 
         tx0' * (x - x0) + tomega0 * (omega - omega_0) - ds];
    errorx = norm(dz) / (norm(z) + 1e-16);
    errorf = norm(G);
    % format short g
    % disp([k z(1) z(2) lambda errorx  errorf])
    if (errorx < epsx) && (errorf < epsf)
        t0 = [tx0; tomega0];

        % t = null([jacob(x, omega, params.func) deromega(x, omega, params.func)]);
        % t = [-(jacob(x, omega, params.func) \ deromega(x, omega, params.func)); 1];
        % t = t / norm(t);
        A = [jacob(x, xct, params.func, JL, flag) deromega(x, omega, params.func)];
        [Q, R] = qr(A');
        t = Q(:, end);

        t = t * sign(t0'*t);
        tx = t(1:end-1);
        tomega = t(end);
        format short g
        disp([params.cont.step  z(1) z(2) omega  errorx  errorf   k])
        % w = FUNCstruct.w; % update w

        %% output slip state
        % xc = x((2 * H + 1) * Na + 1:end);
        % pfunc = params.func;
        FlagState = get_slip_state(flag);
        %%

        return
    end
    if k == maxiter
        tx = 0;
        tomega = 0;
        stop = 1;
    end
end


end

function xct = Fourier_to_Time(Xc, H, Nx, E)

    for i = 1:3 * Nx
        r1 = (2 * H + 1) * (i - 1) + 1;
        r2 = (2 * H + 1) * i;
        X(:,i) = Xc(r1:r2); % reorder in dofs in column
    end
    xct = E * X; 

end

function w = get_w_middle(xc, pfunc)
    H = pfunc.HBM.H;
    N = pfunc.HBM.N;
    Nx = pfunc.HBM.Nx;
    E = pfunc.HBM.E;
    kn = pfunc.fc.kn;
    kt = pfunc.fc.kt;
    w_in = pfunc.fc.w;
    mu = pfunc.fc.mu;

    w = zeros(2, Nx);
    n = 2 * H + 1;
    xtt = zeros(N, 2);
    xtn = zeros(N, 1);
    for i = 1:Nx
        X1 = xc(n * (3 * i - 3) + 1:n * (3 * i - 2));
        X2 = xc(n * (3 * i - 2) + 1:n * (3 * i - 1));
        Xn = xc(n * (3 * i - 1) + 1:n * (3 * i));
        xtt(:, 1) = E * X1 + pfunc.static.preload.xp(3 * i - 2);
        xtt(:, 2) = E * X2 + pfunc.static.preload.xp(3 * i - 1);
        xtn = E * Xn + pfunc.static.preload.xp(3 * i);
        for j = 1:2
            w_plus = xtt(:, j) + mu(j, i) * kn(i) / kt(j, i) * max(xtn, 0);
            w_minus = xtt(:, j) - mu(j, i) * kn(i) / kt(j, i) * max(xtn, 0);
            if min(w_plus) >= max(w_minus)
                w(j, i) = 0.5 * (min(w_plus) + max(w_minus));
            else
                w(j, i) = w_in(j, i);
            end
            % t = [0:N-1]';
            % figure;
            % plot(t, w_plus, 'k-'), hold on;
            % plot(t, w_minus, 'b--'), grid on;
            % plot(t, w(j, i) * ones(N, 1), 'r-');
        end
    end

        
end

function FlagState = get_slip_state(flag)
    Nx = size(flag, 2);
    FlagState = zeros(Nx, 4);
    for i = 1:Nx
        FlagState(i, :) = ismember([2, 1, -1, 0], flag(:, i, :));
    end

end

% function [Ft, wt, Mft] = g_in_cont(xt, kn, xn0, mu, kt, w_in, nloop) % xt, each rows correspond each time, columns are different dofs
% 
%     [N, M] = size(xt);
%     Nx = M / 3;
% 
%     Ft = zeros(nloop * N, M);
%     wt = zeros(2, Nx, nloop * N);
% 
%     Mft = zeros(5, Nx, N * nloop);
% 
%     for j = 1:nloop
%         for i = 1:N
%             [Ft((j - 1) * N + i, :), wtemp, Mf] = gf_in_cont(xt(i, :), kn, xn0, mu, kt, w_in);
%             w_in = wtemp; 
%             wt(:, :, (j - 1) * N + i) = wtemp;
%             Mft(:, :, (j - 1) * N + i) = Mf;
%         end
%     end
% 
% 
% end

% function [F, w, Mf] = gf_in_cont(x, kn, xn0, mu, kt, w_in) % x is a 3*Np dof row vector, represent 2*Np tangential directions and 1*Np normal direction
% 
%     Nx = size(kn, 2); % contact number
%     F = zeros(size(x));
%     w = w_in;
%     Mf = zeros(5, Nx); % condition of friction matix
%     for i = 1:Nx
%         indx1 = 3 * (i - 1) + 1;
%         indx2 = 3 * (i - 1) + 2;
%         indx3 = 3 * (i - 1) + 3;
%         F(indx3) = NormalForces_in_cont(x(indx3), kn(i), xn0(i));
%         if F(indx3) > 0
%             Mf(5, i) = 1;
%         end
%         [F(indx1), w(1, i), Mf(1:2, i)] = TangentialForces_in_cont(x(indx1), w(1, i), kt(1, i), mu(1, i), F(indx3));
%         [F(indx2), w(2, i), Mf(3:4, i)] = TangentialForces_in_cont(x(indx2), w(2, i), kt(2, i), mu(2, i), F(indx3));
%     end
% 
% end

% function [T, w, C] = TangentialForces_in_cont(xt, wt, kt, mu, FN)
%     if FN > 0
%         T = kt * (xt - wt);
%         if abs(T) <= mu * FN
%             w = wt;
%             C = [1; 0]; % stick
%         else
%             sg = sign(T);
%             T = sg * mu * FN;
%             w = xt - sg * mu * FN / kt;
%             C = sg * [0; 1]; % 100% slip
%         end
%     else
%         T = zeros(size(xt));
%         w = xt;
%         C = [0; 0]; % gap, no stick nor slip
%     end
% end

% function FN = NormalForces_in_cont(xn, kn, xn0)
%     u = xn - xn0;
%     FN = max(0, kn .* u);
% end