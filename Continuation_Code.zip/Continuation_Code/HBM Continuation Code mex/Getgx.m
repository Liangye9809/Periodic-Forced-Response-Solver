function F = Getgx(xp, fc)
    [F, ~] = g_mex(xp, fc);
end

